<template>
  <Index></Index>
</template>

<script>
import Index from "@/views/Index.vue";

export default {
  name: "app",
  components: {
    Index,
  }
};
</script>

<style>
body {
  margin: 0;
}
</style>